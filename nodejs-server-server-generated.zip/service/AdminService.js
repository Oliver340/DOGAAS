'use strict';


/**
 * Login admin
 * Login admin
 *
 * body Login Login admin
 * no response value expected for this operation
 **/
exports.adminPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

