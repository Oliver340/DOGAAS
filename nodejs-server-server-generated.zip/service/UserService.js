'use strict';


/**
 * Login User
 * Login user
 *
 * body Login Login user
 * no response value expected for this operation
 **/
exports.userPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete yourself
 * Suicide
 *
 * username String 
 * no response value expected for this operation
 **/
exports.userUsernameDELETE = function(username) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update user
 * Updates a user's personal info
 *
 * body Login Update user (optional)
 * username String 
 * no response value expected for this operation
 **/
exports.userUsernamePUT = function(body,username) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

